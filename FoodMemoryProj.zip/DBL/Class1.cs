﻿namespace DBL
{
    public class Class1
    {

    }
}
